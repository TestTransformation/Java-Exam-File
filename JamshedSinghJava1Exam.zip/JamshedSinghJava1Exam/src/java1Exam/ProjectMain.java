package java1Exam;

import java.util.ArrayList;
import java.util.List;

public class ProjectMain {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		try
		{
		List<TestCase> testCases = new ArrayList<TestCase>();
		
		
		testCases.add(new TestCase(1, "Test a valid credit card"));
		testCases.add(new TestCase(2, "Test another valid credit card"));
		testCases.add(new TestCase(3, "Test an invalid credit card"));
		testCases.add(new TestCase(4, "Test Exceptions"));
	
	for(TestCase testCase:testCases)
	{
	
	//get the description from the testcase
	String tcDescription =testCase.getDescription();
	// get the test case number from the testcase
	int tcNumber = testCase.getTestCaseNumber();
	// setup a format for String.format to match the expected output for "Processing testcase" output
	String format = "Processing testcase: %d : %s";
	// put the arguments for String.format in the correct order
	System.out.println(String.format(format,tcNumber,tcDescription));
	System.out.println(testCase.toString());
	}
		}catch(NullPointerException e)
		{
			System.out.println("A " +e+ "was triggered.It was caused by testcase with no data." );
		}
	
}
}

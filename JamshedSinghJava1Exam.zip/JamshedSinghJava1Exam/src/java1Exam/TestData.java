package java1Exam;

import java.util.HashMap;
import java.util.Map;

public class TestData 
{	

	public Map<Integer, String> TestData = new HashMap<Integer, String>();

	public TestData()
	{
		TestData.put(1, "1234-5678-9012");
		TestData.put(2, "0000-0000-0000");
		TestData.put(3, "1234-AAAA-4567");
	}
	
	public String getData(int _testCaseNumber) 
	{	
		int key = _testCaseNumber;
		String value = TestData.get(key);
		return value;
	}
	
}

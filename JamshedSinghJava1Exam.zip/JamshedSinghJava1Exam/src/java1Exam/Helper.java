package java1Exam;

public class Helper {
	 
	public static String ScrubCreditCardData(String _inputData)
	{
		
		String regexPattern = "^\\d{4}([\\s-])?\\d{4}\\1\\d{4}$";
		
		boolean isValidCreditCard = false;
		
		String output = "";
		
	if (_inputData.matches(regexPattern))
	{
		output = "data scrubbed";
		isValidCreditCard = true;
	}
	else
	{
		output = "something went wrong";
	}
		return output;
	}
			
}

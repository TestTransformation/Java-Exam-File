package java1Exam;

public class TestCase {
	
	private int testCaseNumber;
	public TestCase(int testCaseNumber, String description) {
		super();
		this.testCaseNumber = testCaseNumber;
		this.description = description;
	}


	private String description;
	
	public int getTestCaseNumber() {
		return this.testCaseNumber;
	}
	
	
	public String getDescription() {
		return this.description;
	}
	
	
	//instance created
	TestData testData = new TestData();
	
	
	@Override
	public String toString()
	{
		String format = "TestCase: %d : %s  Data: %s";
	String unScrubbedData = testData.getData(testCaseNumber);
	String scrubbedData = Helper.ScrubCreditCardData(unScrubbedData);
	String output = String.format(format, testCaseNumber, description, scrubbedData);
	return output;
	}
}

package Java1Exam;

import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.*;

/**
 * 
 * @author Subramanian Vaidyanathan
 * 
 * Project Main Class - Created to Define the Main Class flow
 *
 */
public class ProjMain {

	/**
	 * MAIN Method
	 * @param args
	 */
	public static void main(String[] args) {

		//ArrayList to manage the test cases
		List<TestCase> testCases = new ArrayList<TestCase>();
		
		//Adding key value pair to the array list
		testCases.add(new TestCase(1, "Test a valid credit card"));
		testCases.add(new TestCase(2, "Test another valid credit card"));
		testCases.add(new TestCase(3, "Test an invalid credit card"));
		testCases.add(new TestCase(4, "Test Exceptions"));
		
		
		//Exception handling for Nullpointer Exception
		try
		{
			
			for (TestCase testCase:testCases)
			{
				//get the description from the testcase
				String tcDescription =testCase.getDescription();
				// get the test case number from the testcase
				int tcNumber = testCase.getTestCaseNumber();
				// setup a format for String.format to match the expected output for "Processing testcase" output
				String format = "Processing testcase : %d : %s";
				// put the arguments for String.format in the correct order
				System.out.println(String.format(format, tcNumber, tcDescription));
				
				System.out.println(testCase.toString());
			}
			
		}
		catch (NullPointerException e)
		{
					
			System.out.println("A "+e.getClass()+" was triggered. It was caused by a test case with no data");
		}
		
		catch(Exception e)
		{
			System.out.println("A "+e.getClass()+" was triggered.");
		}
	}
	
	
}

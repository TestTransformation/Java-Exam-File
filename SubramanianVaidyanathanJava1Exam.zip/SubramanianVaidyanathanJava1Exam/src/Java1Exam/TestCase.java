package Java1Exam;


/**
 * TestCase class created to define the Encapsulation
 * 
 *  
 */
public class TestCase {

	
	private int testCaseNumber;
	private String description;
	private TestData testData=new TestData(); 
	
	/**
	 * GETTER for TEST CASE NUMBER
	 * @return testCaseNumber
	 */
	public int getTestCaseNumber() {
		return testCaseNumber;
	}

	/**
	 * SETTER for TEST CASE NUMBER
	 * @param testCaseNumber
	 * 	 */
	public void setTestCaseNumber(int testCaseNumber) {
		this.testCaseNumber = testCaseNumber;
	}

	/**
	 * GETTER for DESCRIPTION
	 * @return String
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * SETTER for DESCRIPTION
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Constructor for Test Case Class
	 * @param _testCaseNumber TEST CASE NUMBER
	 * @param _description TEST CASE DESCRIPTION
	 */
	public TestCase(int _testCaseNumber, String _description)
	{
	// set the values of the private variables here with the arguments given to the constructor
		
		testCaseNumber=_testCaseNumber;
		description=_description;
		
	}
	
	@Override
	public String toString()
	{
		// format should contain a format that matches the expected output below
		String format ="Test Case %d: %s . Data :%s";
		
		// unScrubbedData should pull the data out of the TestData class based on the test case number
		String unScrubbedData =testData.getData(testCaseNumber);
				
		// scrubbedData should contain the output of Helper.ScrubCreditCardNumber()
		String scrubbedData =Helper.ScrubCreditCardData(unScrubbedData);
		
		
		String output = String.format(format, testCaseNumber, description, scrubbedData);
		return output;
	}
}

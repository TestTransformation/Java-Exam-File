package Java1Exam;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Test Data class to validate the various data passed on to the Helper class
 */
public class TestData {

	//Created a map to store the test case number & credit card info
	public Map<Integer, String> Map=new HashMap<Integer, String>();

	/**
	 * TesData Constructor to initialize the test data conditions
	 * 
	 */
	
	public TestData()
	{
				
		Map.put(1, "1234-5678-9012");
		Map.put(2, "0000-0000-0000");
		Map.put(3, "1234-AAAA-4567");
	}
	
	/**
	* Method getData - Will return the Credit Card Number specific to the test case number passed
	* @param _testCaseNumber the testcase number (also the Map's key)
	* @return the data for the given test case number
	*/
	public String getData(int _testCaseNumber)
	{
		String output ="NONE";
		output=Map.get(_testCaseNumber);
		//System.out.println(output);
				
		return output;
	}
	
	
	
}

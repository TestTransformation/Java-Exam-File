import java.util.HashMap;
import java.util.Map;
/***
 * 
 * @author HAJJAJ2
 *
 */
public class TestData 
{

	Map<Integer, String> data = new HashMap<Integer, String>();

	public TestData()
	{
	data.put(1, "1234-5678-9012");
	data.put(2, "0000-0000-0000");
	data.put(3, "1234-AAAA-4567");
	}

	public String getData(int _testCaseNumber)
	{
	String output = data.get(_testCaseNumber);
	return output;
	}

}

/***
 * 
 * @author HAJJAJ2
 *
 */
public class Helper 
{
	public static String ScrubCreditCardData(String _inputData)
	{
	// define a regular expression pattern below:
	String regexPattern =  "^[0-9]{4}-[0-9]{4}-[0-9]{4}$";
	// apply the pattern to the inputData
			
	
	// and store the result in the boolean variable below
	boolean isValidCreditCard = _inputData.matches(regexPattern);
	
	String output = "";
	// fill out the following code
	if (isValidCreditCard)
	{
		output="9999-9999-9999";
	}
	else
	{
		output= "<INVALID_CARD>";
	}
	return output;
	}

	
}

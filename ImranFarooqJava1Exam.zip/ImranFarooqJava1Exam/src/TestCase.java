
public class TestCase {
	
	
	/*
	 *  Add a private variable called testCaseNumber
        Add a private variable called description
        Add a private instance of the TestData class called testData
        Add a getter function for testCaseNubmer and description (getTestCaseNumber and getDescription)
	 */
	private int testCaseNumber;
	private String description;
	TestData testData = new TestData();
	
	public int getTestCaseNumber() {
		return testCaseNumber;
	}

	public String getDescription() {
		return description;
	}

	
	
	public TestCase(int _testCaseNumber, String _description)
	{
	// set the values of the private variables here with the arguments given to the constructor
		testCaseNumber = _testCaseNumber;
		description = _description;
		
		
	}

	
	@Override
	public String toString()
	{
	// format should contain a format that matches the expected output below
		String format = "The Test Case No: %d , Description: %s, Test Data %s";

		
	// unScrubbedData should pull the data out of the TestData class based on the test case number
		String unScrubbedData = testData.getData(testCaseNumber);
		
	// scrubbedData should contain the output of Helper.ScrubCreditCardNumber()
		String scrubbedData = Helper.ScrubCreditCardData(unScrubbedData);
		
		String output = String.format(format, testCaseNumber, description, scrubbedData);
		
		return output;
	}
	
	
	
	
}

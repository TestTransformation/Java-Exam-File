import java.util.*;

public class Helper {

		// TODO Auto-generated method stub

		
		/**
		* This function takes in data and if it contains a credit card number,
		* the number is replaced with dummy data (scrubbed)
		* and the dummy data is returned
		*
		* @param _inputData The data to be scrubbed
		* @return the modified data
		*/
		public static String ScrubCreditCardData(String _inputData){
		// define a regular expression pattern below:
		
		String regexPattern1 = "(\\d{4}[- ]){3}\\d{4}|\\d{16}";
		String regexPattern = "[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}";
/**
 * Test Code to match Pattern
 * 		String testccString = "1234567891234123";
 * 	    System.out.println(testccString.format(" \"%s\" matches \"%s\": %s", testccString, regexPattern, testccString.matches(regexPattern)));
 	    boolean resultp1 = testccString.matches(regexPattern1);
		String output12 = testccString.replaceAll(regexPattern1, "****************");
		System.out.println(resultp1);
		System.out.println(output12);
 */
					
		// apply the pattern to the inputData
		// and store the result in the boolean variable below
		
		boolean isValidCreditCard = false;
		String output = "";
		
		isValidCreditCard = _inputData.matches(regexPattern1);
		
		
		// fill out the following code
		if (isValidCreditCard)
		{
					
		// scrub the data here. output should contain
		// the value of the scrubbed data
			output = _inputData.replaceAll(regexPattern1, "****************");
			
		}
		else
		{
		// output should contain a value: "<INVALID_CARD>"
			System.out.println("<INVALID_CARD>");
			
		}

		return output;
		}
		

}

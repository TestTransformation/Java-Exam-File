import java.util.ArrayList;
import java.util.List;

public class ProjectMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Create new List
		List<TestCase> testCases = new ArrayList<TestCase>();
		testCases.add(new TestCase(1, "Test a valid credit card"));
		testCases.add(new TestCase(2, "Test another valid credit card"));
		testCases.add(new TestCase(3, "Test an invalid credit card"));
		testCases.add(new TestCase(4, "Test Exceptions"));
	
		try
		{
			for(TestCase myList: testCases)
			{
				//get the description from the testcase
				String tcDescription = myList.getDescription();
				
				// get the test case number from the testcase
				int tcNumber = myList.getTestCaseNumber();
				
				// setup a format for String.format to match the expected output for "Processing testcase" output
				String format = "Test case reference: %d    Test Description: %s";
				// put the arguments for String.format in the correct order
				System.out.println(String.format(format, tcNumber, tcDescription));
				System.out.println(myList.toString());
			}
		}
		
		catch (NullPointerException o)
				{
			//Catch a NullPointerException and print out a message matching the expected output
					System.out.println(" An exception was triggered: " + o.getMessage());
				}

		catch (Exception p)
		{
			//Catch Exception in another catch block and print the exception�s stack trace
			p.printStackTrace();
		}
		
	}

}

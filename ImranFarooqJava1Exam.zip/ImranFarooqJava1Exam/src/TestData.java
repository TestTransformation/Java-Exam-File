import java.util.HashMap;
import java.util.Map;

public class TestData {

	Map<Integer,String> data=new HashMap<Integer,String>(); 
	/*
	 * Add a Map named data which contains TestCase numbers as Keys and Credit Card Numbers:
     * Pattern: TestCaseNumber -> CreditCard Number
	 */
	public TestData()
	{
	data.put(1, "1234-5678-9012-1122");
	data.put(2, "0000-0000-0000-0000");
	data.put(3, "1234-AAAA-4567-00AA");
	}
	
	/**
	*
	* @param _testCaseNumber the testcase number (also the Map's key)
	* @return the data for the given test case number
	*/
	public String getData(int _testCaseNumber)
	{
	String output = data.get(_testCaseNumber);
	return output;
	}

	public Map<Integer, String> getData() {
		return data;
	}

	public void setData(Map<Integer, String> data) {
		this.data = data;
	}
	
}

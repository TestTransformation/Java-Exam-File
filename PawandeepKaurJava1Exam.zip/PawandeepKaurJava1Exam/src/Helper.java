
public class Helper {

	public Helper() {
		// TODO Auto-generated constructor stub
	}
	/**
	* This function takes in data and if it contains a credit card number,
	* the number is replaced with dummy data (scrubbed)
	* and the dummy data is returned
	*
	* @param _inputData The data to be scrubbed
	* @return the modified data
	*/
	public static String ScrubCreditCardData(String _inputData)
	{
	// define a regular expression pattern below:
	String regexPattern = "\\d{4}[ -]\\d{4}[ -]\\d{4}";
	// apply the pattern to the inputData
	// and store the result in the boolean variable below
	boolean isValidCreditCard = false;
	String output = "";
	if (_inputData.matches(regexPattern))
	{
	output = "9999-9999-9999";
	isValidCreditCard = true;
	}
	else
	{
	output = "<INVALID-CARD>";
	}
	return output;
	}
}


public class Helper {
	/**
	* This function takes in data and if it contains a credit card number,
	* the number is replaced with dummy data (scrubbed)
	* and the dummy data is returned
	*
	* @param _inputData The data to be scrubbed
	* @return the modified data
	*/
	public static String ScrubCreditCardData(String _inputData)
	{
	// define a regular expression pattern below:
	String regexPattern = "\\d{4}-?\\d{4}-?\\d{4}";
	// apply the pattern to the inputData
	boolean isValidCreditCard = _inputData.matches(regexPattern);
	// and store the result in the boolean variable below
	
//	isValidCreditCard = false;
	String output = "";
	// fill out the following code
	if (isValidCreditCard)
	{
		output = "9999-9999-9999";
	// scrub the data here. output should contain
	// the value of the scrubbed data
	}
	else
	{
		output = "<INVALID_CARD>";
	}
	return output;
	}
	
	
}

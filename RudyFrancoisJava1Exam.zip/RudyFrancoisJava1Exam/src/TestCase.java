
public class TestCase {
	
	private int testCaseNumber = 0;
	
	private String description = "";
	
	private TestData testData =new TestData();
	
	public int getTestCaseNumber()
    {
      return testCaseNumber;
    }
	
	public String getDescription()
    {
      return description;
    } 
	
	public TestCase(int _testCaseNumber, String _description)
	{
	testCaseNumber = _testCaseNumber;
	description = _description;
	}
	
	@Override
	public String toString()
	{
	// format should contain a format that matches the expected output below
	String format = "Test Case Number: %d | Test Case Description: %s | Test Data: %s";
	// unScrubbedData should pull the data out of the TestData class based on the test case number
	String unScrubbedData = testData.getData(testCaseNumber);
	// scrubbedData should contain the output of Helper.ScrubCreditCardNumber()
	String scrubbedData = Helper.ScrubCreditCardData(unScrubbedData); 
	String output = String.format(format, testCaseNumber, description, scrubbedData);
	return output;
	}

}

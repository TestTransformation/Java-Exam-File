
public class Helper {

	
	
	public static String ScrubCreditCardData(String _inputData)
	{
	// define a regular expression pattern below:
	//	Visa: ^4[0-9]{12}(?:[0-9]{3})?$ All Visa card numbers start with a 4. New cards have 16 digits. Old cards have 13.
		
		String regexPattern = "^[1-9][0-9]{3}-[0-9]{4}-[0-9]{4}$";
		
	
		 boolean isValidCreditCard = _inputData.matches(regexPattern);

	// apply the pattern to the inputData
	// and store the result in the boolean variable below
	
		

   
	String output = "";
	// fill out the following code
	
	if (isValidCreditCard)
	{
		
	
	output ="9999-9999-9999";
	
	}
	else
	{

         output ="Invalid card";

      System.out.println(output);
      
}
	
	return output;
	}

}
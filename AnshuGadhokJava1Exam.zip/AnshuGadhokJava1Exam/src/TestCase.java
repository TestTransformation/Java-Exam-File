
public class TestCase {

	private int testcaseNumber;

	private String description ;

	private TestData testData = new TestData();
	
	public int getTestcaseNumber() {
		return testcaseNumber;
	}

	

	public String getDescription() {
		return description;
	}

	
	
	
	public TestCase(int _testCaseNumber, String _description)
	
	{
		testcaseNumber = _testCaseNumber;
		
		description = _description;
	
	
	}
	
	
	@Override
	
	
	 
	 

	public String toString()
	
	
	{
		
	// format should contain a format that matches the expected output below

		String format = "TestCase %d : %s . Data:  %s";
	// unScrubbedData should pull the data out of the TestData class based on the test case number
	
	
	String unScrubbedData = testData.getData(testcaseNumber);
	
	
	// scrubbedData should contain the output of Helper.ScrubCreditCardNumber()
	
	String scrubbedData = Helper.ScrubCreditCardData(unScrubbedData);
	
	String output = String.format(format, testcaseNumber, description, scrubbedData);
	
	return output;
	}
	
}

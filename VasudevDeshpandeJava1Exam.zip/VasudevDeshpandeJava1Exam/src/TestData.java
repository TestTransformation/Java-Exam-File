import java.util.*;
import java.util.stream.Collectors;
public class TestData {
	private int TestCaseNumber;
	private String CreditCardNumber;

	public TestData(int TestCaseNumber,String CreditCardNumber)
	{
		this.TestCaseNumber=TestCaseNumber;
		this.CreditCardNumber=CreditCardNumber;
	}
	
	public int getData(int TestCaseNumber)//e.Getters/Setters
	{
		return TestCaseNumber;
	}
	
	public void setData(int TestCaseNumber)
	{
		this.TestCaseNumber=TestCaseNumber;
	}
	
	public static void main(String args[])
	{
Map<Integer, String> data=new HashMap<Integer, String>();
data.put(1, "1234-5678-9012");
data.put(2, "0000-0000-0000");
data.put(3, "1234-AAAA-4567");
System.out.println(data.size());
String p1=data.get(data);
}
	
}

import java.io.*;
import java.nio.file.*;
public class TestCase {

	private int testCaseNumber;
	private String description;
	
	public TestCase(int testCaseNumber, String description)
	{
		this.testCaseNumber=testCaseNumber;
		this.description=description;
		System.out.println(testCaseNumber);
		System.out.println(description);
	}
	
	public int getData(int testCaseNumber)
	{
		return testCaseNumber;
	
	}
	public static void main(String[] args) 
	{
		TestCase obj=new TestCase(5,"Message");
	
	}

}

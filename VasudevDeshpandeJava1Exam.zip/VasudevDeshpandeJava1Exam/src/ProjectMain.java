import java.util.ArrayList;
import java.util.List;

public class ProjectMain {

	public static void main(String[] args) {

		List<TestCase> testCases = new ArrayList<TestCase>();
		testCases.add(new TestCase(1, "Test a valid credit card"));
		testCases.add(new TestCase(2, "Test another valid credit card"));
		testCases.add(new TestCase(3, "Test an invalid credit card"));
		testCases.add(new TestCase(4, "Test Exceptions"));
		
		System.out.println(testCases.size());
	}

}

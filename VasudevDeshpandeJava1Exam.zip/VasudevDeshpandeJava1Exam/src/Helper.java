import java.util.regex.Pattern;

public class Helper {

	private static final String String = null;
	public static void main(String args[])
	{
		String CreditCardnumber= "4999999999999999";
		//String output="0";
		System.out.println(CreditCard(String));
	}
	public static String CreditCard(String CreditCardnumber)
		{
		
		String regexPattern= "^4/d{15}$";
		
		Pattern pattern=Pattern.compile(regexPattern);
		boolean isValidCreditCard=pattern.matches("^4/d{15}$","4999999999999999");
		String output = "4999999999999999";
		
		if (isValidCreditCard==true)
		{
		
			System.out.println("It is a valid credit card" +regexPattern);
		}
		else
		{
		
			System.out.println("It is a invalid credit card number");
		}
		return output;
	}
	
}


